package incometaxcalculator.data.management;

import java.util.HashMap;
import java.util.LinkedHashMap;

import incometaxcalculator.exceptions.WrongReceiptKindException;

public abstract class Taxpayer {

  protected final String fullname;
  protected final int taxRegistrationNumber;
  protected final float income;
  private float amountPerReceiptsKind[] = new float[5];
  private int totalReceiptsGathered = 0;
  private HashMap<Integer, Receipt> receiptHashMap = new HashMap<Integer, Receipt>(0);  
  private static String[] receiptKinds = {"Entertainment", "Basic", "Travel", "Health", "Other"};
  private static LinkedHashMap<String, Integer> receiptKindValues = new LinkedHashMap<String, Integer>(0);
  private static final double taxVariationFactors[] = {0.08, 0.04, -0.15, -0.3};
  private int incomeRange[];
  private double taxMultiplier[];
  private double fixedPaymentAmount[];
  
  public double calculateBasicTax() {   
    if (income < incomeRange[0]) {
      return taxMultiplier[0] * income;
    } else if (income < incomeRange[1]) {
      return fixedPaymentAmount[0] + taxMultiplier[1] * (income - incomeRange[0]);
    } else if (income < incomeRange[2]) {
      return fixedPaymentAmount[1] + taxMultiplier[2] * (income - incomeRange[1]);
    } else if (income < incomeRange[3]) {
      return fixedPaymentAmount[2] + taxMultiplier[3] * (income - incomeRange[2]);
    } else {
      return fixedPaymentAmount[3] + taxMultiplier[4] * (income - incomeRange[3]);
    }
  }

  protected Taxpayer(String fullname, int taxRegistrationNumber, float income) {
    this.fullname = fullname;
    this.taxRegistrationNumber = taxRegistrationNumber;
    this.income = income;
    this.matchValuesToReceiptKinds();
  } 
  
  public void matchValuesToReceiptKinds() {
    for(int i = 0; i < receiptKinds.length; i++) {
      receiptKindValues.put(receiptKinds[i], i);
    }
  }
  
  public void addReceipt(Receipt receipt) throws WrongReceiptKindException {
    for(int i = 0; i < receiptKinds.length; i++ ) {
      if(receiptKinds[i].equals(receipt.getKind())) {
        receiptHashMap.put(receipt.getId(), receipt);
        calculateReceipts(receipt, 1);
        return;
      }
    }    
    
    throw new WrongReceiptKindException();

  }

  public void removeReceipt(int receiptId) throws WrongReceiptKindException {
    Receipt receipt = receiptHashMap.get(receiptId);
    for(int i = 0; i < receiptKinds.length; i++ ) {
      if(receiptKinds[i].equals(receipt.getKind())) {
        calculateReceipts(receipt, -1);
        receiptHashMap.remove(receiptId);
        return;
      }
    }
    throw new WrongReceiptKindException();  
    
  }

  public void calculateReceipts(Receipt receipt, int operator) {
      amountPerReceiptsKind[receiptKindValues.get(receipt.getKind())] = amountPerReceiptsKind[receiptKindValues.get(receipt.getKind())] + operator*receipt.getAmount();
      totalReceiptsGathered = totalReceiptsGathered + operator;
  }
  
  public String getFullname() {
    return fullname;
  }

  public int getTaxRegistrationNumber() {
    return taxRegistrationNumber;
  }
  
  public float getIncome() {
    return income;
  }

  public HashMap<Integer, Receipt> getReceiptHashMap() {
    return receiptHashMap;
  }

  public double getVariationTaxOnReceipts() {
    float totalAmountOfReceipts = getTotalAmountOfReceipts();    
    for(int i=1; i<4; i++) {
      if(totalAmountOfReceipts < i*0.2*income) {
        return calculateBasicTax() * taxVariationFactors[i];
      }
    }
    
    return calculateBasicTax() * taxVariationFactors[4];
    
  }
  
  private float getTotalAmountOfReceipts() {
    int sum = 0;
    for (int i = 0; i < 5; i++) {
      sum += amountPerReceiptsKind[i];
    }
    return sum;
  }
  
  public int getTotalReceiptsGathered() {
    return totalReceiptsGathered;
  }

  public float getAmountOfReceiptKind(short kind) {
    return amountPerReceiptsKind[kind];
  }

  public double getTotalTax() {
    return this.calculateBasicTax() + getVariationTaxOnReceipts();
  }

  public double getBasicTax() {
    return this.calculateBasicTax();
  }
  
  public void setTaxArrayFields(int incomeRange[], double taxMultiplier[], double fixedPaymentAmount[]) {
    this.incomeRange = incomeRange;
    this.taxMultiplier = taxMultiplier;
    this.fixedPaymentAmount = fixedPaymentAmount;
  }
  
}