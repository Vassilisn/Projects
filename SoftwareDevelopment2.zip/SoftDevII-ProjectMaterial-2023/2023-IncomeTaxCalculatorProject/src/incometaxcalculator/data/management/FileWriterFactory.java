package incometaxcalculator.data.management;


import java.io.File;
import java.io.IOException;

import incometaxcalculator.data.io.FileWriter;
import incometaxcalculator.data.io.TXTInfoWriter;
import incometaxcalculator.data.io.TXTLogWriter;
import incometaxcalculator.data.io.XMLInfoWriter;
import incometaxcalculator.data.io.XMLLogWriter;
import incometaxcalculator.exceptions.WrongFileFormatException;

public class FileWriterFactory {
  
  public static FileWriter updateFiles(int taxRegistrationNumber) throws IOException {
        
    if (new File(taxRegistrationNumber + "_INFO.xml").exists()) {
      if (new File(taxRegistrationNumber + "_INFO.txt").exists()) {
        new TXTInfoWriter().generateFile(taxRegistrationNumber);
      }
      return new XMLInfoWriter();
    } else {
      return new TXTInfoWriter();    
    }
    
  }
  
  public static FileWriter saveLogFile(String fileFormat) throws WrongFileFormatException {
    if (fileFormat.equals("txt")) {
      return new TXTLogWriter();
    } else if (fileFormat.equals("xml")) {
      return new XMLLogWriter();
    } else {
      throw new WrongFileFormatException();
    }
  }
  
}
