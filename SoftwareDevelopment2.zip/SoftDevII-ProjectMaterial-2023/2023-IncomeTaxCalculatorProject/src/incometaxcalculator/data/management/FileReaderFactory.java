package incometaxcalculator.data.management;

import incometaxcalculator.data.io.FileReader;
import incometaxcalculator.data.io.TXTFileReader;
import incometaxcalculator.data.io.XMLFileReader;
import incometaxcalculator.exceptions.WrongFileEndingException;

public class FileReaderFactory {

  public static FileReader loadTaxpayer(String fileExtension) throws WrongFileEndingException {
    if (fileExtension.equals("txt")) {
      return new TXTFileReader();
    } else if (fileExtension.equals("xml")) {
      return new XMLFileReader();
    } else {
      throw new WrongFileEndingException();
    }
  }
  
}
