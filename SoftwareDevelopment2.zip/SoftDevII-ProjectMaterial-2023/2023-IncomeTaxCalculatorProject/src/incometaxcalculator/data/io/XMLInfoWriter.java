package incometaxcalculator.data.io;


public class XMLInfoWriter extends InfoWriter {

  
  
  public String getStringConstants(String tag) {
    if (tag.equals("_INFO")) {
      return tag + ".xml";
    }
    if (tag.equals("Receipt ID")) {
      return "<ReceiptID> ";
    }
    return "<" + tag + "> ";
  }
  
  public String getStringConstantsForXML(String tag) {
    if (tag.equals("Receipt ID")) {
      return " </ReceiptID>";
    }
    return " </" + tag + "> ";
  }

}