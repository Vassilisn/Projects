package incometaxcalculator.data.io;

import java.io.IOException;
import java.io.PrintWriter;

import incometaxcalculator.data.management.Receipt;
import incometaxcalculator.data.management.TaxpayerManager;

public abstract class LogWriter implements FileWriter{

  private static final short ENTERTAINMENT = 0;
  private static final short BASIC = 1;
  private static final short TRAVEL = 2;
  private static final short HEALTH = 3;
  private static final short OTHER = 4;
  
  String[] stringTagsGenerateFile = {"_LOG.", "Name", "AFM", "Income", 
      "BasicTax", "TaxIncrease", "TaxDecrease", "TotalTax", "Receipts", 
      "Entertainment", "Basic", "Travel", "Health", "Other"};
  TaxpayerManager manager = new TaxpayerManager(); 
  
  public abstract String getStringConstants(String tag);
  public abstract String getStringConstantsForXML(String tag);

  public void generateFile(int taxRegistrationNumber) throws IOException {
    PrintWriter outputStream = new PrintWriter(
        new java.io.FileWriter(taxRegistrationNumber + getStringConstants(stringTagsGenerateFile[0])));
    outputStream.println(getStringConstants(stringTagsGenerateFile[1]) + manager.getTaxpayerName(taxRegistrationNumber) + getStringConstantsForXML(stringTagsGenerateFile[1]));
    outputStream.println(getStringConstants(stringTagsGenerateFile[2]) + taxRegistrationNumber + getStringConstantsForXML(stringTagsGenerateFile[2]));
    outputStream.println(getStringConstants(stringTagsGenerateFile[3]) + manager.getTaxpayerIncome(taxRegistrationNumber) + getStringConstantsForXML(stringTagsGenerateFile[3]));
    outputStream
        .println(getStringConstants(stringTagsGenerateFile[4]) + manager.getTaxpayerBasicTax(taxRegistrationNumber) + getStringConstantsForXML(stringTagsGenerateFile[4]));
    if (manager.getTaxpayerVariationTaxOnReceipts(taxRegistrationNumber) > 0) {
      outputStream.println(getStringConstants(stringTagsGenerateFile[5])
          + manager.getTaxpayerVariationTaxOnReceipts(taxRegistrationNumber) + getStringConstantsForXML(stringTagsGenerateFile[5]));
    } else {
      outputStream.println(getStringConstants(stringTagsGenerateFile[6])
          + manager.getTaxpayerVariationTaxOnReceipts(taxRegistrationNumber) + getStringConstantsForXML(stringTagsGenerateFile[6]));
    }
    outputStream
        .println(getStringConstants(stringTagsGenerateFile[7]) + manager.getTaxpayerTotalTax(taxRegistrationNumber) + getStringConstantsForXML(stringTagsGenerateFile[7]));
    outputStream.println(
        getStringConstants(stringTagsGenerateFile[8]) + manager.getTaxpayerTotalReceiptsGathered(taxRegistrationNumber) + getStringConstantsForXML(stringTagsGenerateFile[8]));
    outputStream.println(
        getStringConstants(stringTagsGenerateFile[9]) + manager.getTaxpayerAmountOfReceiptKind(taxRegistrationNumber, ENTERTAINMENT)
            + getStringConstantsForXML(stringTagsGenerateFile[9]));
    outputStream.println(
        getStringConstants(stringTagsGenerateFile[10]) + manager.getTaxpayerAmountOfReceiptKind(taxRegistrationNumber, BASIC) + getStringConstantsForXML(stringTagsGenerateFile[10]));
    outputStream.println(
        getStringConstants(stringTagsGenerateFile[11]) + manager.getTaxpayerAmountOfReceiptKind(taxRegistrationNumber, TRAVEL) + getStringConstantsForXML(stringTagsGenerateFile[11]));
    outputStream.println(
        getStringConstants(stringTagsGenerateFile[12]) + manager.getTaxpayerAmountOfReceiptKind(taxRegistrationNumber, HEALTH) + getStringConstantsForXML(stringTagsGenerateFile[12]));
    outputStream.println(
        getStringConstants(stringTagsGenerateFile[13]) + manager.getTaxpayerAmountOfReceiptKind(taxRegistrationNumber, OTHER) + getStringConstantsForXML(stringTagsGenerateFile[13]));
    outputStream.close();
  }

  public int getReceiptId(Receipt receipt) {
    return receipt.getId();
  }
  
  public String getReceiptIssueDate(Receipt receipt) {
    return receipt.getIssueDate();
  }
  
  public String getReceiptKind(Receipt receipt) {
    return receipt.getKind();
  }
  
  public float getReceiptAmount(Receipt receipt) {
    return receipt.getAmount();
  }
  
  public String getCompanyName(Receipt receipt) {
    return receipt.getCompany().getName();
  }
  
  public String getCompanyCountry(Receipt receipt) {
    return receipt.getCompany().getCountry();
  }
  
  public String getCompanyCity(Receipt receipt) {
    return receipt.getCompany().getCity();
  }
  
  public String getCompanyStreet(Receipt receipt) {
    return receipt.getCompany().getStreet();
  }
  
  public int getCompanyNumber(Receipt receipt) {
    return receipt.getCompany().getNumber();
  }
}
