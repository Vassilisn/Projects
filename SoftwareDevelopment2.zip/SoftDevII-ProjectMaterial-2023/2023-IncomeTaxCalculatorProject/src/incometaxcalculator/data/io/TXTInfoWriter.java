package incometaxcalculator.data.io;


public class TXTInfoWriter extends InfoWriter {
  
  public String getStringConstants(String tag) {
    if (tag.equals("_INFO")) {
      return tag + ".txt";
    }
    return tag + ": ";
  }
  
  public String getStringConstantsForXML(String tag) {
    return "";
  }

}