package incometaxcalculator.data.io;


public class TXTFileReader extends FileReader {
  
  protected int checkReceiptValues(String values[]) {
      if (values[1].equals("ID:")) {
        int receiptId = Integer.parseInt(values[2].trim());
        return receiptId;
      }    
    return -1;
  }

  protected String extractFieldValue(String fieldsLine) {
    String values[] = fieldsLine.split(" ", 2);
    values[1] = values[1].trim();
    return values[1];
  }
}