package incometaxcalculator.data.management;

public class MarriedFilingSeparatelyTaxpayer extends Taxpayer {

  private int incomeRange[] = {18040, 71680, 90000, 127120};
  private double taxMultiplier[] = {0.0535, 0.0705, 0.0785, 0.0785, 0.0985};
  private double fixedPaymentAmount[] = {965.14, 4746.76, 6184.88, 9098.80};
  
  public MarriedFilingSeparatelyTaxpayer(String fullname, int taxRegistrationNumber, float income) {
    super(fullname, taxRegistrationNumber, income);
    super.setTaxArrayFields(incomeRange, taxMultiplier, fixedPaymentAmount);
  }
/*
  public double calculateBasicTax() {
    if (income < 18040) {
      return 0.0535 * income;
    } else if (income < 71680) {
      return 965.14 + 0.0705 * (income - 18040);
    } else if (income < 90000) {
      return 4746.76 + 0.0785 * (income - 71680);
    } else if (income < 127120) {
      return 6184.88 + 0.0785 * (income - 90000);
    } else {
      return 9098.80 + 0.0985 * (income - 127120);
    }
  }
*/
}